class Usuario {
    constructor(id,nombre,apellido,email,telefono,direccion){
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
        this.telefono = telefono;
        this.direccion = direccion
        this.isAdmin = false;
    }
}