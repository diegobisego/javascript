class ProductoVenta {
    constructor(id,cantidad,precUnit) {
        this.id = id
        this.cantidad = cantidad
        this.precUnit = precUnit
    }
}